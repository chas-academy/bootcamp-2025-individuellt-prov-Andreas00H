export function combineStrings(strings) {
  let result = "";
  strings.forEach((string) => {
    result += string;
  });

  return result;
}
