export function measureString(string) {
  return string.length;
}

export function measureArray(array) {
  return array.length;
}
