const data = [
  { name: "John", age: 20 },
  { name: "Jane", age: 31 },
  { name: "Jim", age: 13 },
];

const getName = (person) => {
  return person.name;
};

export const getAllNames = () => {
  let names = [];
  data.forEach((person) => {
    names.push(getName(person));
  });
  return names;
};
