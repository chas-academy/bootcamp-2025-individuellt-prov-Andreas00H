export const mathEquation = (a) => {
  const b = 2;
  return a + b;
};
